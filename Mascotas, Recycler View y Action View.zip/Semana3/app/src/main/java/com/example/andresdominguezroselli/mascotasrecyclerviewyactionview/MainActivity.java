package com.example.andresdominguezroselli.mascotasrecyclerviewyactionview;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{


    private RecyclerView listMascotas;
    ArrayList<Mascota> mascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        toolbar_title.setText(R.string.txtMascotas);
        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        listMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        LayoutManager llm = new LinearLayoutManager(this);
        llm.getPaddingTop();
        //llm.setOrientation(LinearLayoutManager.VERTICAL);

        listMascotas.setLayoutManager(llm);

        initMascotas();
        inicilizarAdaptador();
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_Menu) {
            Toast.makeText(this,"Menu de solo vista",Toast.LENGTH_LONG).show();
        }

        return super.onOptionsItemSelected(item);
    }
    private void inicilizarAdaptador(){
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listMascotas.setAdapter(adaptador);
    }

    public void initMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(1,"Chester",R.drawable.cat,"2"));
        mascotas.add(new Mascota(1,"Daysi",R.drawable.clown_fish,"4"));
        mascotas.add(new Mascota(1,"Perry",R.drawable.cow,"5"));
        mascotas.add(new Mascota(1,"Bestia",R.drawable.duck,"6"));
        mascotas.add(new Mascota(1,"Corsar",R.drawable.frog,"8"));
        mascotas.add(new Mascota(1,"Zu",R.drawable.giraffe,"0"));
        mascotas.add(new Mascota(1,"Zuri",R.drawable.lion,"5"));
        mascotas.add(new Mascota(1,"Monster",R.drawable.penguin,"1"));
        mascotas.add(new Mascota(1,"Terry",R.drawable.pig,"5"));
        mascotas.add(new Mascota(1,"Pinky",R.drawable.toucan,"9"));
    }

    public void getList(View v){
        Intent intent = new Intent(MainActivity.this,SegundaPantalla.class);
        startActivity(intent);
    }
}