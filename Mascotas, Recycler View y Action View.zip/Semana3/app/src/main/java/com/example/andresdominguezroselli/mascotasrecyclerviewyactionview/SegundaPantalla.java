package com.example.andresdominguezroselli.mascotasrecyclerviewyactionview;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import java.util.ArrayList;


public class SegundaPantalla extends AppCompatActivity{
    private RecyclerView listMascotas;
    ArrayList<Mascota> mascotas;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.segunda_pantalla);

        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        toolbar_title.setText(R.string.txtFavoritos);

        Button btnShowCollection = (Button) findViewById(R.id.btnShowCollection);
        btnShowCollection.setVisibility(View.GONE);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        listMascotas = (RecyclerView) findViewById(R.id.rvFavoritos);

        LayoutManager llm = new LinearLayoutManager(this);
        llm.getPaddingTop();


        listMascotas.setLayoutManager(llm);

        initMascotas();
        inicilizarAdaptador();
    }
    private void inicilizarAdaptador(){
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listMascotas.setAdapter(adaptador);
    }

    public void initMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(1,"Daysi",R.drawable.clown_fish,"4"));
        mascotas.add(new Mascota(1,"Bestia",R.drawable.duck,"6"));
        mascotas.add(new Mascota(1,"Corsar",R.drawable.frog,"8"));
        mascotas.add(new Mascota(1,"Zuri",R.drawable.lion,"5"));
        mascotas.add(new Mascota(1,"Monster",R.drawable.penguin,"1"));

    }
}
